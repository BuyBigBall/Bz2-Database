import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.apache.commons.compress.compressors.CompressorException;
import org.apache.commons.compress.compressors.CompressorInputStream;
import org.apache.commons.compress.compressors.CompressorStreamFactory;

import java.io.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class App {
    private final Set<String> createdLinks;
    private final Set<String> createdSubreddits;

    public App() {
        createdLinks = new HashSet<>();
        createdSubreddits = new HashSet<>();
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost/reddit?user=root&password=");
    }

    @SuppressWarnings("all")
    private void init() throws IOException {
        BufferedReader br = requestInputForTheFilePath();
        if (br == null) {
            return;
        }

        long startTime = ZonedDateTime.now().toInstant().toEpochMilli();
        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);
            PreparedStatement psSubreddits = connection.prepareStatement(
                    "INSERT INTO subreddits (subreddit_id, subreddit) VALUES (?, ?);");

            PreparedStatement psLinks = connection.prepareStatement(
                    "INSERT INTO links (link_id, subreddit_id) VALUES (?, ?);");

            PreparedStatement psComments = connection.prepareStatement("INSERT INTO comments "
                    + "(id, parent_id, link_id, author_id, created_utc, body, score, ups, downs) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);");

            String line;
            int recordsProcessed = 0;
            System.out.println("Started processing records...");
            while ((line = br.readLine()) != null) {
                JsonObject jsonObject = new Gson().fromJson(line, JsonObject.class);

                String subredditId = jsonObject.get("subreddit_id").getAsString();
                String linkId = jsonObject.get("link_id").getAsString();

                if (!createdSubreddits.contains(subredditId)) {
                    psSubreddits.setString(1, subredditId);
                    psSubreddits.setString(2, jsonObject.get("subreddit").getAsString());
                    psSubreddits.addBatch();
                    createdSubreddits.add(subredditId);
                }

                if (!createdLinks.contains(linkId) && createdSubreddits.contains(subredditId)) {
                    psLinks.setString(1, linkId);
                    psLinks.setString(2, subredditId);
                    psLinks.addBatch();
                    createdLinks.add(linkId);
                }

                psComments.setString(1, jsonObject.get("id").getAsString());
                psComments.setString(2, jsonObject.get("parent_id").getAsString());
                psComments.setString(3, linkId);
                psComments.setString(4, jsonObject.get("author").getAsString());
                long createdUtc = jsonObject.get("created_utc").getAsLong();
                psComments.setTimestamp(5, new Timestamp(
                        getDateTimeFromEpochSecond(createdUtc).toEpochSecond(ZoneOffset.UTC)));
                psComments.setString(6, jsonObject.get("body").getAsString());
                psComments.setInt(7, jsonObject.get("score").getAsInt());
                psComments.setInt(8, jsonObject.get("up") != null ? jsonObject.get("up").getAsInt() : 0);
                psComments.setInt(9, jsonObject.get("down") != null ? jsonObject.get("down").getAsInt() : 0);
                psComments.addBatch();

                recordsProcessed++;
                if (recordsProcessed % 100000 == 0) {
                    System.out.println(recordsProcessed + " records processed.");
                    if (recordsProcessed % 1000000 == 0) {
                        System.out.println("Executing batches up to now.");
                        executeBatches(psSubreddits, psLinks, psComments);
                    }
                }
            }

            executeBatches(psSubreddits, psLinks, psComments);
            System.out.println("Commiting to DB...");
            connection.commit();

            long endTime = ZonedDateTime.now().toInstant().toEpochMilli();
            long elapsedTime = endTime - startTime;
            System.out.println("\nElapsed Time: " + elapsedTime / 1000.0d + "s");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void executeBatches(PreparedStatement psSubreddits,
                                PreparedStatement psLinks,
                                PreparedStatement psComments) throws SQLException {
        System.out.println("Executing subreddits batch...");
        psSubreddits.executeBatch();

        System.out.println("Executing links batch...");
        psLinks.executeBatch();

        System.out.println("Executing comments batch...");
        psComments.executeBatch();
    }

    private BufferedReader requestInputForTheFilePath() {
        System.out.println("Enter the file Path: ");
        Scanner input = new Scanner(System.in);
        try {
            return getBufferedReaderForCompressedFile(input.nextLine());
        } catch (FileNotFoundException | CompressorException e) {
            e.printStackTrace();
        }
        return null;
    }

    private BufferedReader getBufferedReaderForCompressedFile(String fileIn)
            throws FileNotFoundException, CompressorException {
        FileInputStream fin = new FileInputStream(fileIn);
        BufferedInputStream bis = new BufferedInputStream(fin);
        CompressorInputStream input = new CompressorStreamFactory().createCompressorInputStream(bis);
        return new BufferedReader(new InputStreamReader(input));
    }

    private LocalDateTime getDateTimeFromEpochSecond(long epochSecond) {
        return LocalDateTime.ofEpochSecond(epochSecond * 1000, 0, ZoneOffset.UTC);
    }

    public static void main(String[] args) throws IOException {
        new App().init();
    }

}
